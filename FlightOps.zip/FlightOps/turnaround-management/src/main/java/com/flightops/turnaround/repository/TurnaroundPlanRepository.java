package com.flightops.turnaround.repository;

import com.flightops.turnaround.entity.TurnaroundPlan;
import com.flightops.turnaround.entity.TurnaroundPlan.PlanStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface TurnaroundPlanRepository extends JpaRepository<TurnaroundPlan, Long> {

    Optional<TurnaroundPlan> findByFlightId(Long flightId);

    List<TurnaroundPlan> findByStatus(PlanStatus status);

    List<TurnaroundPlan> findBySupervisorId(Long supervisorId);

    boolean existsByFlightId(Long flightId);

    @Query("SELECT tp FROM TurnaroundPlan tp WHERE tp.status = 'ACTIVE' AND tp.supervisorId = :supervisorId")
    List<TurnaroundPlan> findActiveBySupERvisorId(@Param("supervisorId") Long supervisorId);

    @Query("SELECT COUNT(tp) FROM TurnaroundPlan tp WHERE tp.status = :status")
    long countByStatus(@Param("status") PlanStatus status);
}
