package com.flightops.turnaround.controller;

import com.flightops.turnaround.dto.ApiResponse;
import com.flightops.turnaround.dto.MilestoneCompletionRequest;
import com.flightops.turnaround.dto.MilestoneRequest;
import com.flightops.turnaround.dto.MilestoneResponse;
import com.flightops.turnaround.service.TurnaroundMilestoneService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/v1/turnaround-milestones")
@RequiredArgsConstructor
public class TurnaroundMilestoneController {

    private final TurnaroundMilestoneService milestoneService;

    // POST /api/v1/turnaround-milestones
    @PostMapping
    public ResponseEntity<ApiResponse<MilestoneResponse>> addMilestone(
            @Valid @RequestBody MilestoneRequest request) {
        MilestoneResponse response = milestoneService.addMilestone(request);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success(response, "Milestone added successfully"));
    }

    // GET /api/v1/turnaround-milestones/{milestoneId}
    @GetMapping("/{milestoneId}")
    public ResponseEntity<ApiResponse<MilestoneResponse>> getMilestoneById(@PathVariable Long milestoneId) {
        return ResponseEntity.ok(ApiResponse.success(
                milestoneService.getMilestoneById(milestoneId), "Milestone retrieved successfully"));
    }

    // GET /api/v1/turnaround-milestones/plan/{planId}
    @GetMapping("/plan/{planId}")
    public ResponseEntity<ApiResponse<List<MilestoneResponse>>> getMilestonesByPlan(@PathVariable Long planId) {
        return ResponseEntity.ok(ApiResponse.success(
                milestoneService.getMilestonesByPlan(planId), "Milestones retrieved successfully"));
    }

    // GET /api/v1/turnaround-milestones/plan/{planId}/delayed
    @GetMapping("/plan/{planId}/delayed")
    public ResponseEntity<ApiResponse<List<MilestoneResponse>>> getDelayedMilestones(@PathVariable Long planId) {
        return ResponseEntity.ok(ApiResponse.success(
                milestoneService.getDelayedMilestones(planId), "Delayed milestones retrieved successfully"));
    }

    // PATCH /api/v1/turnaround-milestones/{milestoneId}/complete
    @PatchMapping("/{milestoneId}/complete")
    public ResponseEntity<ApiResponse<MilestoneResponse>> completeMilestone(
            @PathVariable Long milestoneId,
            @Valid @RequestBody MilestoneCompletionRequest request) {
        return ResponseEntity.ok(ApiResponse.success(
                milestoneService.completeMilestone(milestoneId, request), "Milestone updated successfully"));
    }

    // PATCH /api/v1/turnaround-milestones/{milestoneId}/planned-time
    @PatchMapping("/{milestoneId}/planned-time")
    public ResponseEntity<ApiResponse<MilestoneResponse>> updatePlannedTime(
            @PathVariable Long milestoneId,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime plannedTime) {
        return ResponseEntity.ok(ApiResponse.success(
                milestoneService.updatePlannedTime(milestoneId, plannedTime), "Planned time updated successfully"));
    }

    // DELETE /api/v1/turnaround-milestones/{milestoneId}
    @DeleteMapping("/{milestoneId}")
    public ResponseEntity<ApiResponse<Void>> deleteMilestone(@PathVariable Long milestoneId) {
        milestoneService.deleteMilestone(milestoneId);
        return ResponseEntity.ok(ApiResponse.success(null, "Milestone deleted successfully"));
    }
}
