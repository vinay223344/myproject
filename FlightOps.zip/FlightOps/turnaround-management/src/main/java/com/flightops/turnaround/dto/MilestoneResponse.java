package com.flightops.turnaround.dto;

import com.flightops.turnaround.entity.TurnaroundMilestone.MilestoneStatus;
import com.flightops.turnaround.entity.TurnaroundMilestone.MilestoneType;
import lombok.Builder;
import lombok.Data;
import java.time.LocalDateTime;

@Data
@Builder
public class MilestoneResponse {
    private Long milestoneId;
    private Long planId;
    private MilestoneType milestoneType;
    private LocalDateTime plannedTime;
    private LocalDateTime actualTime;
    private Long completedById;
    private MilestoneStatus status;
    private Long delayMinutes; // null if on time or not yet completed
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}
