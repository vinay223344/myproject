package com.flightops.turnaround.dto;

import com.flightops.turnaround.entity.TurnaroundPlan.PlanStatus;
import lombok.Builder;
import lombok.Data;
import java.time.LocalDateTime;
import java.util.List;

@Data
@Builder
public class TurnaroundPlanResponse {
    private Long planId;
    private Long flightId;
    private Integer targetTurnaroundMinutes;
    private Integer actualTurnaroundMinutes;
    private Long supervisorId;
    private PlanStatus status;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    private List<MilestoneResponse> milestones;
    private long delayedMilestoneCount;
    private long completedMilestoneCount;
    private long pendingMilestoneCount;
}
