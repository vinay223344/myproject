package com.flightops.turnaround.controller;

import com.flightops.turnaround.dto.ApiResponse;
import com.flightops.turnaround.dto.TurnaroundPlanRequest;
import com.flightops.turnaround.dto.TurnaroundPlanResponse;
import com.flightops.turnaround.entity.TurnaroundPlan.PlanStatus;
import com.flightops.turnaround.service.TurnaroundPlanService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/v1/turnaround-plans")
@RequiredArgsConstructor
public class TurnaroundPlanController {

    private final TurnaroundPlanService planService;

    // POST /api/v1/turnaround-plans
    @PostMapping
    public ResponseEntity<ApiResponse<TurnaroundPlanResponse>> createPlan(
            @Valid @RequestBody TurnaroundPlanRequest request) {
        TurnaroundPlanResponse response = planService.createPlan(request);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success(response, "Turnaround plan created successfully"));
    }

    // GET /api/v1/turnaround-plans
    @GetMapping
    public ResponseEntity<ApiResponse<List<TurnaroundPlanResponse>>> getAllPlans(
            @RequestParam(required = false) PlanStatus status) {
        List<TurnaroundPlanResponse> plans = (status != null)
                ? planService.getPlansByStatus(status)
                : planService.getAllPlans();
        return ResponseEntity.ok(ApiResponse.success(plans, "Plans retrieved successfully"));
    }

    // GET /api/v1/turnaround-plans/{planId}
    @GetMapping("/{planId}")
    public ResponseEntity<ApiResponse<TurnaroundPlanResponse>> getPlanById(@PathVariable Long planId) {
        return ResponseEntity.ok(ApiResponse.success(planService.getPlanById(planId), "Plan retrieved successfully"));
    }

    // GET /api/v1/turnaround-plans/flight/{flightId}
    @GetMapping("/flight/{flightId}")
    public ResponseEntity<ApiResponse<TurnaroundPlanResponse>> getPlanByFlightId(@PathVariable Long flightId) {
        return ResponseEntity.ok(ApiResponse.success(
                planService.getPlanByFlightId(flightId), "Plan retrieved successfully"));
    }

    // GET /api/v1/turnaround-plans/supervisor/{supervisorId}
    @GetMapping("/supervisor/{supervisorId}")
    public ResponseEntity<ApiResponse<List<TurnaroundPlanResponse>>> getPlansBySupervisor(
            @PathVariable Long supervisorId) {
        return ResponseEntity.ok(ApiResponse.success(
                planService.getPlansBySupervisor(supervisorId), "Plans retrieved successfully"));
    }

    // PUT /api/v1/turnaround-plans/{planId}
    @PutMapping("/{planId}")
    public ResponseEntity<ApiResponse<TurnaroundPlanResponse>> updatePlan(
            @PathVariable Long planId,
            @Valid @RequestBody TurnaroundPlanRequest request) {
        return ResponseEntity.ok(ApiResponse.success(
                planService.updatePlan(planId, request), "Turnaround plan updated successfully"));
    }

    // PATCH /api/v1/turnaround-plans/{planId}/status
    @PatchMapping("/{planId}/status")
    public ResponseEntity<ApiResponse<TurnaroundPlanResponse>> updateStatus(
            @PathVariable Long planId,
            @RequestParam PlanStatus status) {
        return ResponseEntity.ok(ApiResponse.success(
                planService.updatePlanStatus(planId, status), "Plan status updated successfully"));
    }

    // DELETE /api/v1/turnaround-plans/{planId}
    @DeleteMapping("/{planId}")
    public ResponseEntity<ApiResponse<Void>> deletePlan(@PathVariable Long planId) {
        planService.deletePlan(planId);
        return ResponseEntity.ok(ApiResponse.success(null, "Turnaround plan deleted successfully"));
    }
}
