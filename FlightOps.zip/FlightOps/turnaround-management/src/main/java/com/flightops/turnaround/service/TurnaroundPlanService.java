package com.flightops.turnaround.service;

import com.flightops.turnaround.dto.TurnaroundPlanRequest;
import com.flightops.turnaround.dto.TurnaroundPlanResponse;
import com.flightops.turnaround.entity.TurnaroundPlan;
import com.flightops.turnaround.entity.TurnaroundPlan.PlanStatus;
import com.flightops.turnaround.exception.BusinessException;
import com.flightops.turnaround.exception.ResourceNotFoundException;
import com.flightops.turnaround.repository.TurnaroundMilestoneRepository;
import com.flightops.turnaround.repository.TurnaroundPlanRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class TurnaroundPlanService {

    private final TurnaroundPlanRepository planRepository;
    private final TurnaroundMilestoneRepository milestoneRepository;
    private final MilestoneMapper milestoneMapper;

    @Transactional
    public TurnaroundPlanResponse createPlan(TurnaroundPlanRequest request) {
        if (planRepository.existsByFlightId(request.getFlightId())) {
            throw new BusinessException("A turnaround plan already exists for flight ID: " + request.getFlightId());
        }

        TurnaroundPlan plan = TurnaroundPlan.builder()
                .flightId(request.getFlightId())
                .targetTurnaroundMinutes(request.getTargetTurnaroundMinutes())
                .supervisorId(request.getSupervisorId())
                .status(PlanStatus.ACTIVE)
                .build();

        plan = planRepository.save(plan);
        log.info("Created turnaround plan [planId={}] for flight [flightId={}]", plan.getPlanId(), plan.getFlightId());
        return mapToResponse(plan);
    }

    @Transactional(readOnly = true)
    public TurnaroundPlanResponse getPlanById(Long planId) {
        TurnaroundPlan plan = findPlanOrThrow(planId);
        return mapToResponse(plan);
    }

    @Transactional(readOnly = true)
    public TurnaroundPlanResponse getPlanByFlightId(Long flightId) {
        TurnaroundPlan plan = planRepository.findByFlightId(flightId)
                .orElseThrow(() -> new ResourceNotFoundException("No turnaround plan found for flight ID: " + flightId));
        return mapToResponse(plan);
    }

    @Transactional(readOnly = true)
    public List<TurnaroundPlanResponse> getAllPlans() {
        return planRepository.findAll().stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<TurnaroundPlanResponse> getPlansByStatus(PlanStatus status) {
        return planRepository.findByStatus(status).stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<TurnaroundPlanResponse> getPlansBySupervisor(Long supervisorId) {
        return planRepository.findBySupervisorId(supervisorId).stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Transactional
    public TurnaroundPlanResponse updatePlanStatus(Long planId, PlanStatus newStatus) {
        TurnaroundPlan plan = findPlanOrThrow(planId);

        // COMPLETED plan cannot be reopened
        if (plan.getStatus() == PlanStatus.COMPLETED) {
            throw new BusinessException("Cannot change status of a completed turnaround plan.");
        }

        plan.setStatus(newStatus);

        // When marking as COMPLETED, calculate actual turnaround time
        if (newStatus == PlanStatus.COMPLETED) {
            calculateActualTurnaroundTime(plan);
        }

        plan = planRepository.save(plan);
        log.info("Updated plan [planId={}] status to {}", planId, newStatus);
        return mapToResponse(plan);
    }

    @Transactional
    public TurnaroundPlanResponse updatePlan(Long planId, TurnaroundPlanRequest request) {
        TurnaroundPlan plan = findPlanOrThrow(planId);

        if (plan.getStatus() == PlanStatus.COMPLETED) {
            throw new BusinessException("Cannot modify a completed turnaround plan.");
        }

        plan.setTargetTurnaroundMinutes(request.getTargetTurnaroundMinutes());
        plan.setSupervisorId(request.getSupervisorId());

        plan = planRepository.save(plan);
        log.info("Updated turnaround plan [planId={}]", planId);
        return mapToResponse(plan);
    }

    @Transactional
    public void deletePlan(Long planId) {
        TurnaroundPlan plan = findPlanOrThrow(planId);
        if (plan.getStatus() == PlanStatus.ACTIVE) {
            throw new BusinessException("Cannot delete an active turnaround plan. Mark it as completed or delayed first.");
        }
        planRepository.delete(plan);
        log.info("Deleted turnaround plan [planId={}]", planId);
    }

    // Auto-flag plan as DELAYED if any milestone is delayed
    @Transactional
    public void checkAndFlagDelay(Long planId) {
        TurnaroundPlan plan = findPlanOrThrow(planId);
        long delayedCount = milestoneRepository.countByPlanIdAndStatus(
                planId, com.flightops.turnaround.entity.TurnaroundMilestone.MilestoneStatus.DELAYED);

        if (delayedCount > 0 && plan.getStatus() == PlanStatus.ACTIVE) {
            plan.setStatus(PlanStatus.DELAYED);
            planRepository.save(plan);
            log.warn("Plan [planId={}] flagged as DELAYED due to {} delayed milestone(s)", planId, delayedCount);
        }
    }

    private void calculateActualTurnaroundTime(TurnaroundPlan plan) {
        // Actual turnaround = time between CHOCKS_ON and PUSHBACK_CLEARANCE
        var chocksOn = milestoneRepository
                .findByTurnaroundPlan_PlanIdAndMilestoneType(plan.getPlanId(),
                        com.flightops.turnaround.entity.TurnaroundMilestone.MilestoneType.CHOCKS_ON);
        var pushback = milestoneRepository
                .findByTurnaroundPlan_PlanIdAndMilestoneType(plan.getPlanId(),
                        com.flightops.turnaround.entity.TurnaroundMilestone.MilestoneType.PUSHBACK_CLEARANCE);

        if (chocksOn.isPresent() && pushback.isPresent()
                && chocksOn.get().getActualTime() != null
                && pushback.get().getActualTime() != null) {
            long minutes = java.time.Duration.between(
                    chocksOn.get().getActualTime(),
                    pushback.get().getActualTime()).toMinutes();
            plan.setActualTurnaroundMinutes((int) minutes);
        }
    }

    private TurnaroundPlan findPlanOrThrow(Long planId) {
        return planRepository.findById(planId)
                .orElseThrow(() -> new ResourceNotFoundException("Turnaround plan not found with ID: " + planId));
    }

    TurnaroundPlanResponse mapToResponse(TurnaroundPlan plan) {
        List<com.flightops.turnaround.dto.MilestoneResponse> milestoneResponses =
                milestoneRepository.findByTurnaroundPlan_PlanId(plan.getPlanId())
                        .stream().map(milestoneMapper::toResponse)
                        .collect(Collectors.toList());

        return TurnaroundPlanResponse.builder()
                .planId(plan.getPlanId())
                .flightId(plan.getFlightId())
                .targetTurnaroundMinutes(plan.getTargetTurnaroundMinutes())
                .actualTurnaroundMinutes(plan.getActualTurnaroundMinutes())
                .supervisorId(plan.getSupervisorId())
                .status(plan.getStatus())
                .createdAt(plan.getCreatedAt())
                .updatedAt(plan.getUpdatedAt())
                .milestones(milestoneResponses)
                .delayedMilestoneCount(milestoneResponses.stream()
                        .filter(m -> m.getStatus() == com.flightops.turnaround.entity.TurnaroundMilestone.MilestoneStatus.DELAYED)
                        .count())
                .completedMilestoneCount(milestoneResponses.stream()
                        .filter(m -> m.getStatus() == com.flightops.turnaround.entity.TurnaroundMilestone.MilestoneStatus.COMPLETED)
                        .count())
                .pendingMilestoneCount(milestoneResponses.stream()
                        .filter(m -> m.getStatus() == com.flightops.turnaround.entity.TurnaroundMilestone.MilestoneStatus.PENDING)
                        .count())
                .build();
    }
}
