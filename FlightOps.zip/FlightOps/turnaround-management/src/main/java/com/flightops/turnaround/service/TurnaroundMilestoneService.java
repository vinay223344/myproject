package com.flightops.turnaround.service;

import com.flightops.turnaround.dto.MilestoneCompletionRequest;
import com.flightops.turnaround.dto.MilestoneRequest;
import com.flightops.turnaround.dto.MilestoneResponse;
import com.flightops.turnaround.entity.TurnaroundMilestone;
import com.flightops.turnaround.entity.TurnaroundMilestone.MilestoneStatus;
import com.flightops.turnaround.entity.TurnaroundMilestone.MilestoneType;
import com.flightops.turnaround.entity.TurnaroundPlan;
import com.flightops.turnaround.entity.TurnaroundPlan.PlanStatus;
import com.flightops.turnaround.exception.BusinessException;
import com.flightops.turnaround.exception.ResourceNotFoundException;
import com.flightops.turnaround.repository.TurnaroundMilestoneRepository;
import com.flightops.turnaround.repository.TurnaroundPlanRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class TurnaroundMilestoneService {

    private final TurnaroundMilestoneRepository milestoneRepository;
    private final TurnaroundPlanRepository planRepository;
    private final TurnaroundPlanService planService;
    private final MilestoneMapper milestoneMapper;

    @Transactional
    public MilestoneResponse addMilestone(MilestoneRequest request) {
        TurnaroundPlan plan = findActivePlanOrThrow(request.getPlanId());

        if (milestoneRepository.existsByTurnaroundPlan_PlanIdAndMilestoneType(
                request.getPlanId(), request.getMilestoneType())) {
            throw new BusinessException("Milestone " + request.getMilestoneType()
                    + " already exists for plan ID: " + request.getPlanId());
        }

        TurnaroundMilestone milestone = TurnaroundMilestone.builder()
                .turnaroundPlan(plan)
                .milestoneType(request.getMilestoneType())
                .plannedTime(request.getPlannedTime())
                .status(MilestoneStatus.PENDING)
                .build();

        milestone = milestoneRepository.save(milestone);
        log.info("Added milestone [{}] to plan [planId={}]", request.getMilestoneType(), request.getPlanId());
        return milestoneMapper.toResponse(milestone);
    }

    @Transactional(readOnly = true)
    public MilestoneResponse getMilestoneById(Long milestoneId) {
        return milestoneMapper.toResponse(findMilestoneOrThrow(milestoneId));
    }

    @Transactional(readOnly = true)
    public List<MilestoneResponse> getMilestonesByPlan(Long planId) {
        if (!planRepository.existsById(planId)) {
            throw new ResourceNotFoundException("Turnaround plan not found with ID: " + planId);
        }
        return milestoneRepository.findByTurnaroundPlan_PlanId(planId)
                .stream().map(milestoneMapper::toResponse)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<MilestoneResponse> getDelayedMilestones(Long planId) {
        return milestoneRepository.findDelayedMilestones(planId)
                .stream().map(milestoneMapper::toResponse)
                .collect(Collectors.toList());
    }

    @Transactional
    public MilestoneResponse completeMilestone(Long milestoneId, MilestoneCompletionRequest request) {
        TurnaroundMilestone milestone = findMilestoneOrThrow(milestoneId);

        if (milestone.getStatus() == MilestoneStatus.COMPLETED) {
            throw new BusinessException("Milestone is already completed.");
        }

        // Validate that the plan is still active
        TurnaroundPlan plan = milestone.getTurnaroundPlan();
        if (plan.getStatus() == PlanStatus.COMPLETED) {
            throw new BusinessException("Cannot update milestones on a completed turnaround plan.");
        }

        // Determine if actual completion is delayed vs planned
        MilestoneStatus resolvedStatus = request.getStatus();
        if (resolvedStatus == MilestoneStatus.COMPLETED
                && milestone.getPlannedTime() != null
                && request.getActualTime().isAfter(milestone.getPlannedTime())) {
            resolvedStatus = MilestoneStatus.DELAYED;
        }

        milestone.setActualTime(request.getActualTime());
        milestone.setCompletedById(request.getCompletedById());
        milestone.setStatus(resolvedStatus);

        milestone = milestoneRepository.save(milestone);
        log.info("Milestone [milestoneId={}] marked as {} at {}", milestoneId, resolvedStatus, request.getActualTime());

        // Check if plan needs to be flagged as DELAYED
        if (resolvedStatus == MilestoneStatus.DELAYED) {
            planService.checkAndFlagDelay(plan.getPlanId());
        }

        // Auto-complete plan when PUSHBACK_CLEARANCE is completed
        if (milestone.getMilestoneType() == MilestoneType.PUSHBACK_CLEARANCE
                && resolvedStatus != MilestoneStatus.SKIPPED) {
            planService.updatePlanStatus(plan.getPlanId(), PlanStatus.COMPLETED);
        }

        return milestoneMapper.toResponse(milestone);
    }

    @Transactional
    public MilestoneResponse updatePlannedTime(Long milestoneId, LocalDateTime newPlannedTime) {
        TurnaroundMilestone milestone = findMilestoneOrThrow(milestoneId);

        if (milestone.getStatus() != MilestoneStatus.PENDING) {
            throw new BusinessException("Can only update planned time for PENDING milestones.");
        }

        milestone.setPlannedTime(newPlannedTime);
        milestone = milestoneRepository.save(milestone);
        log.info("Updated planned time for milestone [milestoneId={}]", milestoneId);
        return milestoneMapper.toResponse(milestone);
    }

    @Transactional
    public void deleteMilestone(Long milestoneId) {
        TurnaroundMilestone milestone = findMilestoneOrThrow(milestoneId);

        if (milestone.getStatus() == MilestoneStatus.COMPLETED) {
            throw new BusinessException("Cannot delete a completed milestone.");
        }

        milestoneRepository.delete(milestone);
        log.info("Deleted milestone [milestoneId={}]", milestoneId);
    }

    private TurnaroundPlan findActivePlanOrThrow(Long planId) {
        TurnaroundPlan plan = planRepository.findById(planId)
                .orElseThrow(() -> new ResourceNotFoundException("Turnaround plan not found with ID: " + planId));

        if (plan.getStatus() == PlanStatus.COMPLETED) {
            throw new BusinessException("Cannot add milestones to a completed turnaround plan.");
        }
        return plan;
    }

    private TurnaroundMilestone findMilestoneOrThrow(Long milestoneId) {
        return milestoneRepository.findById(milestoneId)
                .orElseThrow(() -> new ResourceNotFoundException("Milestone not found with ID: " + milestoneId));
    }
}
