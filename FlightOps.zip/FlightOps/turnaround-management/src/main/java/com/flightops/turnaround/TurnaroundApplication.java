package com.flightops.turnaround;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TurnaroundApplication {
    public static void main(String[] args) {
        SpringApplication.run(TurnaroundApplication.class, args);
    }
}
