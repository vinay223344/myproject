package com.flightops.turnaround.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "turnaround_milestone")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class TurnaroundMilestone {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long milestoneId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "plan_id", nullable = false)
    private TurnaroundPlan turnaroundPlan;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private MilestoneType milestoneType;

    private LocalDateTime plannedTime;

    private LocalDateTime actualTime;

    private Long completedById;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private MilestoneStatus status;

    @Column(updatable = false)
    private LocalDateTime createdAt;

    private LocalDateTime updatedAt;

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        updatedAt = LocalDateTime.now();
        if (status == null) status = MilestoneStatus.PENDING;
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }

    public enum MilestoneType {
        CHOCKS_ON,
        DOOR_OPEN,
        STAIRS_DOCKED,
        BAGGAGE_OFFLOAD,
        CLEANING,
        CATERING,
        FUELLING,
        BOARDING_COMPLETE,
        DOOR_CLOSE,
        PUSHBACK_CLEARANCE
    }

    public enum MilestoneStatus {
        PENDING, COMPLETED, SKIPPED, DELAYED
    }
}
