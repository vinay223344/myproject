package com.flightops.turnaround.service;

import com.flightops.turnaround.dto.MilestoneResponse;
import com.flightops.turnaround.entity.TurnaroundMilestone;
import org.springframework.stereotype.Component;

import java.time.Duration;

@Component
public class MilestoneMapper {

    public MilestoneResponse toResponse(TurnaroundMilestone milestone) {
        Long delayMinutes = null;

        // Calculate delay in minutes if milestone was completed/delayed and both times exist
        if (milestone.getActualTime() != null && milestone.getPlannedTime() != null) {
            long diff = Duration.between(milestone.getPlannedTime(), milestone.getActualTime()).toMinutes();
            if (diff > 0) {
                delayMinutes = diff;
            }
        }

        return MilestoneResponse.builder()
                .milestoneId(milestone.getMilestoneId())
                .planId(milestone.getTurnaroundPlan().getPlanId())
                .milestoneType(milestone.getMilestoneType())
                .plannedTime(milestone.getPlannedTime())
                .actualTime(milestone.getActualTime())
                .completedById(milestone.getCompletedById())
                .status(milestone.getStatus())
                .delayMinutes(delayMinutes)
                .createdAt(milestone.getCreatedAt())
                .updatedAt(milestone.getUpdatedAt())
                .build();
    }
}
