package com.flightops.turnaround.dto;

import com.flightops.turnaround.entity.TurnaroundMilestone.MilestoneType;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import java.time.LocalDateTime;

@Data
public class MilestoneRequest {

    @NotNull(message = "Plan ID is required")
    private Long planId;

    @NotNull(message = "Milestone type is required")
    private MilestoneType milestoneType;

    @NotNull(message = "Planned time is required")
    private LocalDateTime plannedTime;
}
