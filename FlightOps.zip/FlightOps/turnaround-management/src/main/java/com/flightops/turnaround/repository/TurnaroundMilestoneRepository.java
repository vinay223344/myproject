package com.flightops.turnaround.repository;

import com.flightops.turnaround.entity.TurnaroundMilestone;
import com.flightops.turnaround.entity.TurnaroundMilestone.MilestoneStatus;
import com.flightops.turnaround.entity.TurnaroundMilestone.MilestoneType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface TurnaroundMilestoneRepository extends JpaRepository<TurnaroundMilestone, Long> {

    List<TurnaroundMilestone> findByTurnaroundPlan_PlanId(Long planId);

    List<TurnaroundMilestone> findByTurnaroundPlan_PlanIdAndStatus(Long planId, MilestoneStatus status);

    Optional<TurnaroundMilestone> findByTurnaroundPlan_PlanIdAndMilestoneType(Long planId, MilestoneType milestoneType);

    boolean existsByTurnaroundPlan_PlanIdAndMilestoneType(Long planId, MilestoneType milestoneType);

    @Query("SELECT m FROM TurnaroundMilestone m WHERE m.turnaroundPlan.planId = :planId AND m.status = 'DELAYED'")
    List<TurnaroundMilestone> findDelayedMilestones(@Param("planId") Long planId);

    @Query("SELECT COUNT(m) FROM TurnaroundMilestone m WHERE m.turnaroundPlan.planId = :planId AND m.status = :status")
    long countByPlanIdAndStatus(@Param("planId") Long planId, @Param("status") MilestoneStatus status);
}
