package com.flightops.turnaround.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class TurnaroundPlanRequest {

    @NotNull(message = "Flight ID is required")
    private Long flightId;

    @NotNull(message = "Target turnaround minutes is required")
    @Min(value = 1, message = "Target turnaround minutes must be at least 1")
    private Integer targetTurnaroundMinutes;

    @NotNull(message = "Supervisor ID is required")
    private Long supervisorId;
}
