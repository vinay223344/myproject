package com.flightops.turnaround.dto;

import com.flightops.turnaround.entity.TurnaroundMilestone.MilestoneStatus;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import java.time.LocalDateTime;

@Data
public class MilestoneCompletionRequest {

    @NotNull(message = "Completed by (user ID) is required")
    private Long completedById;

    @NotNull(message = "Actual time is required")
    private LocalDateTime actualTime;

    @NotNull(message = "Status is required")
    private MilestoneStatus status; // COMPLETED, SKIPPED, DELAYED
}
