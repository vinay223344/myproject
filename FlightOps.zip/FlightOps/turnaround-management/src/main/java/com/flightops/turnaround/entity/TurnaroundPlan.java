package com.flightops.turnaround.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "turnaround_plan")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class TurnaroundPlan {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long planId;

    @Column(nullable = false)
    private Long flightId;

    @Column(nullable = false)
    private Integer targetTurnaroundMinutes;

    private Integer actualTurnaroundMinutes;

    @Column(nullable = false)
    private Long supervisorId;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private PlanStatus status;

    @Column(updatable = false)
    private LocalDateTime createdAt;

    private LocalDateTime updatedAt;

    @OneToMany(mappedBy = "turnaroundPlan", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<TurnaroundMilestone> milestones;

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        updatedAt = LocalDateTime.now();
        if (status == null) status = PlanStatus.ACTIVE;
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }

    public enum PlanStatus {
        ACTIVE, COMPLETED, DELAYED
    }
}
