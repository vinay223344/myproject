-- ============================================================
-- FlightOps - Aircraft Turnaround Management Module
-- MySQL Database Setup Script
-- ============================================================

-- Step 1: Create and select the database
CREATE DATABASE IF NOT EXISTS flightops_turnaround
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE flightops_turnaround;

-- ============================================================
-- Table: turnaround_plan
-- Tracks the overall turnaround plan per flight
-- ============================================================
CREATE TABLE IF NOT EXISTS turnaround_plan (
    plan_id                     BIGINT          NOT NULL AUTO_INCREMENT,
    flight_id                   BIGINT          NOT NULL,
    target_turnaround_minutes   INT             NOT NULL,
    actual_turnaround_minutes   INT             NULL,
    supervisor_id               BIGINT          NOT NULL,
    status                      ENUM('ACTIVE', 'COMPLETED', 'DELAYED') NOT NULL DEFAULT 'ACTIVE',
    created_at                  DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at                  DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    PRIMARY KEY (plan_id),
    UNIQUE KEY uq_turnaround_plan_flight (flight_id),
    INDEX idx_turnaround_plan_status (status),
    INDEX idx_turnaround_plan_supervisor (supervisor_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- Table: turnaround_milestone
-- Tracks individual milestone events within a turnaround plan
-- ============================================================
CREATE TABLE IF NOT EXISTS turnaround_milestone (
    milestone_id        BIGINT      NOT NULL AUTO_INCREMENT,
    plan_id             BIGINT      NOT NULL,
    milestone_type      ENUM(
                            'CHOCKS_ON',
                            'DOOR_OPEN',
                            'STAIRS_DOCKED',
                            'BAGGAGE_OFFLOAD',
                            'CLEANING',
                            'CATERING',
                            'FUELLING',
                            'BOARDING_COMPLETE',
                            'DOOR_CLOSE',
                            'PUSHBACK_CLEARANCE'
                        ) NOT NULL,
    planned_time        DATETIME    NULL,
    actual_time         DATETIME    NULL,
    completed_by_id     BIGINT      NULL,
    status              ENUM('PENDING', 'COMPLETED', 'SKIPPED', 'DELAYED') NOT NULL DEFAULT 'PENDING',
    created_at          DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at          DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    PRIMARY KEY (milestone_id),
    -- A plan can have each milestone type only once
    UNIQUE KEY uq_milestone_plan_type (plan_id, milestone_type),
    INDEX idx_milestone_plan (plan_id),
    INDEX idx_milestone_status (status),
    CONSTRAINT fk_milestone_plan
        FOREIGN KEY (plan_id) REFERENCES turnaround_plan (plan_id)
        ON DELETE CASCADE
        ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- Sample seed data (optional, remove in production)
-- ============================================================

-- Sample turnaround plan for flight 1001
INSERT INTO turnaround_plan (flight_id, target_turnaround_minutes, supervisor_id, status)
VALUES (1001, 45, 501, 'ACTIVE');

-- Sample milestones for the plan above (plan_id = 1)
INSERT INTO turnaround_milestone (plan_id, milestone_type, planned_time, status) VALUES
(1, 'CHOCKS_ON',          '2024-06-07 08:00:00', 'PENDING'),
(1, 'DOOR_OPEN',          '2024-06-07 08:05:00', 'PENDING'),
(1, 'STAIRS_DOCKED',      '2024-06-07 08:06:00', 'PENDING'),
(1, 'BAGGAGE_OFFLOAD',    '2024-06-07 08:10:00', 'PENDING'),
(1, 'CLEANING',           '2024-06-07 08:20:00', 'PENDING'),
(1, 'CATERING',           '2024-06-07 08:25:00', 'PENDING'),
(1, 'FUELLING',           '2024-06-07 08:15:00', 'PENDING'),
(1, 'BOARDING_COMPLETE',  '2024-06-07 08:38:00', 'PENDING'),
(1, 'DOOR_CLOSE',         '2024-06-07 08:40:00', 'PENDING'),
(1, 'PUSHBACK_CLEARANCE', '2024-06-07 08:45:00', 'PENDING');
